<?php 

/*******************************************************************************************/
/*
/*		Designed by 'AS Designing'
/*		Web: http://www.asdesigning.com
/*		Web: http://www.astemplates.com
/*		License: Creative Commons
/*
/*******************************************************************************************/

include 'params/fonts.google.php';

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// General Parameters


$page_width 				= 960;
$content_width 				= 960;
$padding 					= 30;
$sidebar_modulepadding		= 25;
$main_sepwidth 				= 25;
$main_modulepadding			= 25;
$footer_sidepadding		 	= 30;
$footer_modulepadding 		= 25;

$content_width = $page_width	= $this->params->get('page_width'); 
$sidebar_width 					= $this->params->get('sidebar_width');
$breadrow_inputwidth			= $sidebar_width - 38;

$layout_type					= 'left';


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Template styles


$tmpl_style		= $this->params->get('tmpl_style');


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Body font family


$body_fontfamily 	= $this->params->get('body_fontfamily');

$google_font 	= array('fontlink'=>false, 'fontfamily'=>false);
$google_font 	= googleFontChooser($body_fontfamily);

$body_fontfamily = $google_font['fontfamily'];


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Body heading font family
 
 
$body_hfontfamily 		= $this->params->get('body_hfontfamily');

$google_hfont = array('fontlink'=>false, 'fontfamily'=>false);
$google_hfont = googleFontChooser($body_hfontfamily);

$body_hfontfamily = $google_hfont['fontfamily'];


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Body fonts

$body_fontsize 			= $this->params->get('body_fontsize'); 
$body_fontweight 		= $this->params->get('body_fontweight'); 
$body_fontstyle 		= $this->params->get('body_fontstyle'); 


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


$custom_css 			= htmlspecialchars($this->params->get('custom_css')); 


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

$hspan = "	var h = asjQuery(this).html();
			var index = h.indexOf(' ');
			if(index == -1) {
				index = h.length;
			}
			asjQuery(this).html('<span>' + h.substring(0, index) + '</span>' + h.substring(index, h.length));";
			
			
include 'params/params.header.php';
include 'params/params.sidebars.php';
include 'params/params.content.php';
include 'params/params.footer.php';

?>

