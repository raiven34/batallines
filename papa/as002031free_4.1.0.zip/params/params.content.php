<?php 

/*******************************************************************************************/
/*
/*		Designed by 'AS Designing'
/*		Web: http://www.asdesigning.com
/*		Web: http://www.astemplates.com
/*		License: Creative Commons
/*
/*******************************************************************************************/

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Main column parameters
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


$main_location 	= 'left';	

$body_bg = '';
if($this->countModules('slider'))
	$body_bg = 'class="fullheader"';
	
	
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Main Column - Dimensions


$main_width = $content_width;

if ($leftcolumn)
{
	$main_width = $content_width - $sidebar_width - $padding;
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


$main_blogcols2width = 0;
$main_blogcols3width = 0;
$main_blogcols4width = 0;

$main_componentwidth = $main_width - 52;

if($leftcolumn && $rightcolumn)
{
	$main_blogcols2width = ($main_componentwidth - $padding) / 2;
	$main_blogcols3width = $main_componentwidth;
	$main_blogcols4width = $main_componentwidth;
}
else
{
	$main_blogcols2width = ($main_componentwidth - $padding) / 2;
	$main_blogcols3width = ($main_componentwidth - $padding * 2) / 3;
	$main_blogcols4width = ($main_componentwidth - $padding * 3) / 4;
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Fonts


$body_h1fontsize 			= $this->params->get('body_h1fontsize'); 
$body_h2fontsize 			= $this->params->get('body_h2fontsize'); 
$body_h3fontsize 			= $this->params->get('body_h3fontsize'); 
$body_h4fontsize 			= $this->params->get('body_h4fontsize'); 
$body_h5fontsize 			= $this->params->get('body_h5fontsize'); 
$body_h12fontweight 		= $this->params->get('body_h12fontweight');
$body_h35fontweight 		= $this->params->get('body_h35fontweight');
$body_htransform		 	= $this->params->get('body_htransform');


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Separator height between featured articles


$main_itemseparator = 25;

if(JRequest::getVar('tmpl') != 'component')
{
	if($featured_view && $menu_params->get('num_columns'))
	{
		$featured_rows = ceil($menu_params->get('num_intro_articles') / $menu_params->get('num_columns') - 1);
	}
}
	
?>
