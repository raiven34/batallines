<?php 

/*******************************************************************************************/
/*
/*		Designed by 'AS Designing'
/*		Web: http://www.asdesigning.com
/*		Web: http://www.astemplates.com
/*		License: Creative Commons
/*
/*******************************************************************************************/


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Header parameters
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Header - Row 3 
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Header - Row 3 (Logo)


$logo_type 			= $this->params->get('logo_type',0); 
$logo_img 			= $this->baseurl . '/templates/' . $this->template . '/images/companylogo.png';

if ($this->params->get('logo_img')) 
{ 
	$logo_img = $this->params->get('logo_img');

	if($logo_img == 'companylogo.png') 
	{
		$logo_img = $this->baseurl . '/templates/' . $this->template . '/images/companylogo.png';
	}
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


$logo_txt 					= htmlspecialchars($this->params->get('logo_txt')); 
$logo_txtfontsize 			= $this->params->get('logo_txtfontsize'); 
$logo_txtfontstyle 			= $this->params->get('logo_txtfontstyle'); 
$logo_txtfontweight 		= $this->params->get('logo_txtfontweight'); 

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Header - Row 3 (Slogan)


$slogan_txt 				= htmlspecialchars($this->params->get('slogan_txt')); 
$slogan_txtfontsize 		= $this->params->get('slogan_txtfontsize'); 
$slogan_txtfontstyle 		= $this->params->get('slogan_txtfontstyle'); 
$slogan_txtfontweight 		= $this->params->get('slogan_txtfontweight'); 


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Header - Row 2
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Top Menu


$topmenu_fontsize 			= $this->params->get('topmenu_fontsize'); 
$topmenu_fontweight 		= $this->params->get('topmenu_fontweight'); 


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Main Menu

	
$mainmenu_fontweight 		= $this->params->get('mainmenu_fontweight'); 
$mainmenu_fontsize 			= $this->params->get('mainmenu_fontsize'); 

$submenu_fontweight 		= $this->params->get('submenu_fontweight'); 
$submenu_fontsize 			= $this->params->get('submenu_fontsize'); 
$submenu_width	 			= '215'; 

$mainmenu_parentmark 		= $this->baseurl . '/templates/' . $this->template . '/images/mark.parent.png';

	
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Header - Row 3
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


$row3col1_width = 'auto';


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Breadcrumbs


$breadrow_texttransform 	= $this->params->get('breadrow_texttransform');
$breadrow_textalign		 	= $this->params->get('breadrow_textalign');
$breadrow_fontsize 			= $this->params->get('breadrow_fontsize');
$breadrow_fontweight		= $this->params->get('breadrow_fontweight');

?>
