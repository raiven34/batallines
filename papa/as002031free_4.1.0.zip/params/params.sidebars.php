<?php 

/*******************************************************************************************/
/*
/*		Designed by 'AS Designing'
/*		Web: http://www.asdesigning.com
/*		Web: http://www.astemplates.com
/*		License: Creative Commons
/*
/*******************************************************************************************/

$sidecolumn123_inputwidth 	= $sidebar_width - 41;
$sidecolumn45_inputwidth 	= $sidebar_width - $sidebar_modulepadding * 2 - 10;

$sidecolumn_h1fontsize 		= $this->params->get('sidecolumn_h1fontsize');
$sidecolumn_h2fontsize 		= $this->params->get('sidecolumn_h2fontsize');
$sidecolumn_h3fontsize 		= $this->params->get('sidecolumn_h3fontsize');
$sidecolumn_h4fontsize 		= $this->params->get('sidecolumn_h4fontsize');
$sidecolumn_h5fontsize 		= $this->params->get('sidecolumn_h5fontsize');

$sidecolumn_hfontweight 	= $this->params->get('sidecolumn_hfontweight');
$sidecolumn_htransform	 	= $this->params->get('sidecolumn_htransform');

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Left Column Parameters
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


$leftcolumn = 0;
$leftcolumn += (bool) $this->countModules('position-40');
$leftcolumn += (bool) $this->countModules('position-41');
$leftcolumn += (bool) $this->countModules('position-42');
$leftcolumn += (bool) $this->countModules('position-43');
$leftcolumn += (bool) $this->countModules('position-44');


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

?>
