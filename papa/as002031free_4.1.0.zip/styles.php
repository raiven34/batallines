<style type="text/css">

/***************************************************************************************/
/*
/*		Designed by 'AS Designing'
/*		Web: http://www.asdesigning.com
/*		Web: http://www.astemplates.com
/*		License: Creative Commons
/*
/**************************************************************************************/

/**************************************************************************************/
/**************************************************************************************/
/*   Elements
/**************************************************************************************/
/**************************************************************************************/


body
{
	<?php echo $body_fontfamily; ?>
	text-align: <?php echo $layout_type; ?>;	
	font-size: <?php echo $body_fontsize; ?>;
	font-style: <?php echo $body_fontstyle; ?>;
	font-weight: <?php echo $body_fontweight; ?>;
}

.wrapper
{
}

h1
{
	font-size: <?php echo $body_h1fontsize; ?>;
}

h2
{
	font-size: <?php echo $body_h2fontsize; ?>;
}

h3
{
	font-size: <?php echo $body_h3fontsize; ?>;
}

h4
{
	font-size: <?php echo $body_h4fontsize; ?>;
}

h5
{
	font-size: <?php echo $body_h5fontsize; ?>;
}

h1, 
h2, 
h3,
h4,
h5,
.article-info
{
	<?php echo $body_hfontfamily; ?>	
	text-align: <?php echo $layout_type; ?>;	
}

h1, 
h2
{
	font-weight: <?php echo $body_h12fontweight; ?>;	
}

h3,
h4,
h5,
.article-info
{
	font-weight: <?php echo $body_h12fontweight; ?>;	
}

blockquote 
{
	text-align: <?php echo $layout_type; ?>;
}

.inputbox,
#jform_name,
#jform_username,
#jform_password1,
#jform_password2,
#jform_email,
#jform_email1,
#jform_email2,
#jform_title,
#jform_url,
#jform_catid,
#jform_state,
#jform_params_editor,
#jform_params_timezone,
#jform_params_language,
#jform_params_admin_style,
#jform_params_admin_language,
#jform_params_helpsite,
#username,
#password
{
	float: <?php echo $layout_type; ?>;
}


/**************************************************************************************/
/*   Header
/**************************************************************************************/
/**************************************************************************************/


#header
{
	font-size: <?php echo $body_fontsize; ?>;
	font-weight: <?php echo $body_fontweight; ?>;
	font-style: <?php echo $body_fontstyle; ?>;
	<?php echo $body_fontfamily; ?>;
}

#header .content
{
	width: <?php echo $content_width; ?>px;		
}


/**************************************************************************************/
/*   Header Row 0					      											  */

#header .row0
{
}

#header .row0 .content
{
	width: <?php echo $page_width; ?>px;		
}

#header .row0 ul.menu li a
{
	font-size: <?php echo $topmenu_fontsize; ?>;
	font-weight: <?php echo $topmenu_fontweight; ?>;
	<?php echo $body_hfontfamily; ?>			
}

/**************************************************************************************/
/*   Header Row 2 - Main Menu														  */



#header .row2 #mainmenu
{
}

#header .row2 #mainmenu ul.menu li a
{
	font-size: <?php echo $mainmenu_fontsize; ?>;
	font-weight: <?php echo $mainmenu_fontweight; ?>;
	<?php echo $body_hfontfamily; ?>
}

#header .row2 #mainmenu ul.menu ul 
{
	width: <?php echo $submenu_width; ?>px !important;	
}

#header .row2 #mainmenu ul.menu ul li
{
	width: <?php echo $submenu_width; ?>px !important;	
}

#header .row2 #mainmenu ul.menu ul li a 
{
	font-size: <?php echo $submenu_fontsize; ?>;
	font-weight: <?php echo $submenu_fontweight; ?>;
	<?php echo $body_hfontfamily; ?>			
}

#header .row2 #mainmenu ul.menu ul ul
{
	width: <?php echo ($submenu_width+5); ?>px !important;		
	left: <?php echo $submenu_width; ?>px;
}

#header .row2 #mainmenu ul.menu ul ul li
{
	width: <?php echo ($submenu_width+5); ?>px !important;		
}


/**************************************************************************************/
/*   Header Row 3																	  */


#header .row3 .content
{
	width: <?php echo $page_width; ?>px;		
}

#header .row3col1
{
	width: <?php echo $row3col1_width; ?>;
}

#header .row3 #companyname,
#header .row3 #companyname a
{
    font-size: <?php echo $logo_txtfontsize; ?>;
    font-style: <?php echo $logo_txtfontstyle; ?>;
    font-weight: <?php echo $logo_txtfontweight; ?>;
	<?php echo $body_hfontfamily; ?>			
}

#header .row3 .slogan
{
    font-size: <?php echo $slogan_txtfontsize; ?>;
    font-style: <?php echo $slogan_txtfontstyle; ?>;
    font-weight: <?php echo $slogan_txtfontweight; ?>;
	<?php echo $body_hfontfamily; ?>			
}

#header .row3col2
{
}


/**************************************************************************************/
/*  Breadcrums				  														  */


.breadrow .content
{
	font-size: <?php echo $breadrow_fontsize; ?>;
	font-weight: <?php echo $breadrow_fontweight; ?>;
	width: <?php echo $content_width; ?>px;	
	<?php echo $body_fontfamily; ?>		
	text-transform: <?php echo $breadrow_texttransform; ?>;
	text-align: <?php echo $breadrow_textalign; ?>; 
}

.breadrow #searchbox input
{
	<?php echo $body_fontfamily; ?>;
	font-size: <?php echo $body_fontsize; ?>;
	font-style: <?php echo $body_fontstyle; ?>;
	font-weight: <?php echo $body_fontweight; ?>;	
	width: <?php echo $breadrow_inputwidth; ?>px;
}


/**************************************************************************************/
/**************************************************************************************/
/*   Content
/**************************************************************************************/
/**************************************************************************************/

#content
{
	width: <?php echo $content_width; ?>px;	
}


/**************************************************************************************/
/*   Column Left
/**************************************************************************************/
/**************************************************************************************/

#colleft
{
	width: <?php echo $sidebar_width; ?>px;
	margin: 0px <?php echo $padding; ?>px 0px 0px;		
}

#colleft h1
{
	font-size: <?php echo $sidecolumn_h1fontsize; ?>;
}

#colleft h2
{
	font-size: <?php echo $sidecolumn_h2fontsize; ?>;
}

#colleft h3
{
	font-size: <?php echo $sidecolumn_h3fontsize; ?>;
}

#colleft h4
{
	font-size: <?php echo $sidecolumn_h4fontsize; ?>;
}

#colleft h5
{
	font-size: <?php echo $sidecolumn_h5fontsize; ?>;
}

#colleft h1, 
#colleft h2, 
#colleft h3,
#colleft h4,
#colleft h5
{
	font-weight: <?php echo $sidecolumn_hfontweight; ?>;
	text-transform: <?php echo $sidecolumn_htransform; ?>;
}

#colleft input
{
	width: <?php echo $sidecolumn123_inputwidth; ?>px;
}

#colleft #colleft_rows_45 .moduletable form,
#colleft #colleft_rows_45 .moduletable .menu,
#colleft #colleft_rows_45 .moduletable .custom
{
	padding: <?php echo $main_modulepadding; ?>px;
}

#colleft #colleft_rows_45 input
{
	width: <?php echo $sidecolumn45_inputwidth; ?>px;
}


/**************************************************************************************/
/*   Column Main 
/**************************************************************************************/
/**************************************************************************************/

#colmain
{
	width: <?php echo $main_width; ?>px;
	float: <?php echo $main_location; ?>;
	text-align: <?php echo $layout_type; ?>;	
}

#colmain #component,
#cmp_content
{
	width: <?php echo $main_componentwidth; ?>px;
	<?php echo $body_fontfamily; ?>;
	font-size: <?php echo $body_fontsize; ?>;
	font-style: <?php echo $body_fontstyle; ?>;
	font-weight: <?php echo $body_fontweight; ?>;
	<?php echo $cmp_bgpattern; ?>	
	<?php echo $cmp_bgcolor; ?>		
}

#colmain h1,
#cmp_colmain h1
{
	font-size: <?php echo $body_h1fontsize; ?>;
}

#colmain h2,
#cmp_colmain h2
{
	font-size: <?php echo $body_h2fontsize; ?>;
}

#colmain h3,
#cmp_colmain h1
{
	font-size: <?php echo $body_h3fontsize; ?>;
}

#colmain h4
{
	font-size: <?php echo $body_h4fontsize; ?>;
}

#colmain h5
{
	font-size: <?php echo $body_h5fontsize; ?>;
}

#colmain h1, 
#colmain h2, 
#colmain h3,
#cmp_colmain h1,
#cmp_colmain h2,
#cmp_colmain h3
{
	text-transform: <?php echo $body_htransform; ?>;
}

#colmain h4,
#colmain h5
{
	text-transform: <?php echo $body_htransform; ?>;
}

#colmain h1, 
#colmain h2, 
#cmp_colmain h1,
#cmp_colmain h2
{
	font-weight: <?php echo $body_h12fontweight; ?>;	
}

#colmain h3,
#colmain h4,
#colmain h5,
#cmp_colmain h3,
#cmp_colmain h4,
#cmp_colmain h5
{
	font-weight: <?php echo $body_h35fontweight; ?>;	
}

#colmain #component h1,
#colmain #component h2,
#colmain #component h3,
#colmain #adsense h1,
#colmain #adsense h2,
#colmain #adsense h3,
#cmp_colmain h1,
#cmp_colmain h2,
#cmp_colmain h3
{
	<?php echo $body_hbgcolor; ?>
}

#colmain input,
#colmain textarea
{
	<?php echo $body_fontfamily; ?>;
}

#colmain input[type="checkbox"],
#colmain input[type="radio"]
{
}

#colmain p
{
	text-align: <?php echo $layout_type; ?>;
}

#colmain .item-separator
{
	height: <?php echo $main_itemseparator; ?>px;
}

#colmain .blog-featured .items-row.row-<?php echo $featured_rows; ?> .item-separator
{
	height: 0px !important;
}

#colmain .cols-2 .column-1,
#colmain .cols-2 .column-2
{
    width: <?php echo $main_blogcols2width;  ?>px;
}

#colmain .cols-3 .column-1,
#colmain .cols-3 .column-2,
#colmain .cols-3 .column-3
{
    width: <?php echo $main_blogcols3width;  ?>px;
}

#colmain .cols-4 .column-1,
#colmain .cols-4 .column-2,
#colmain .cols-4 .column-3,
#colmain .cols-4 .column-4
{
    width: <?php echo $main_blogcols4width;  ?>px;
}

#colmain .cols-2 .column-1,
#colmain .cols-3 .column-1,
#colmain .cols-3 .column-2,
#colmain .cols-4 .column-1,
#colmain .cols-4 .column-2,
#colmain .cols-4 .column-3
{
    margin: 0px <?php echo $padding;  ?>px 0px 0px;
}

#colmain .cols-2 .column-2,
#colmain .cols-3 .column-3,
#colmain .cols-4 .column-4
{
    margin: 0px 0px 0px 0px;
}

.address
{
	text-align: <?php echo $layout_type; ?>;	
}

.article-info
{
	text-transform: <?php echo $body_htransform; ?>;
}


/**************************************************************************************/
/**************************************************************************************/
/*   Footer
/**************************************************************************************/
/**************************************************************************************/

#footer .content
{
	width: <?php echo $footer_row2_width; ?>px;			
}

#footer .row2 .content
{
	width: <?php echo $footer_row2_width; ?>px;			
}


/**************************************************************************************/
/*   Footer Row 3	   																  */


#footer .row3
{
	font-size: <?php echo $footer_row3_fontsize; ?>;
	font-weight: <?php echo $footer_row3_fontweight; ?>;
	text-transform: <?php echo $footer_row3_texttransform; ?>;	
}

#footer .row3 .content
{
	width: <?php echo $footer_row3_width; ?>px;		
}


/**************************************************************************************/
/**************************************************************************************/
/*   General Element IDs and classes
/**************************************************************************************/
/**************************************************************************************/

button, 
.button,
.btn,
.next,
.previous, 
.validate, 
.readmore, 
#component p.readmore,
#login-form ul.unstyled li
{
	text-transform: <?php echo $btn_txttransform; ?>;
	<?php echo $body_hfontfamily; ?>
}

.separatordotted_hor
{
	margin: 0px 0px 25px 0px;
}

.separatordotted_ver
{
}


/**************************************************************************************/
/**************************************************************************************/
/*   Custom CSS
/**************************************************************************************/
/**************************************************************************************/


<?php echo $custom_css; ?>

</style>